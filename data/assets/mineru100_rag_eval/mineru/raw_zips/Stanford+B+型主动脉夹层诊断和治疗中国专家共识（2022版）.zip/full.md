·指南与共识·

# Stanford B 型主动脉夹层诊断和治疗 中国专家共识(2022 版)

中华医学会外科学分会血管外科学组

Stanford B型主动脉夹层(type B aortic dissection, TBAD)是一种严重危害生命健康的血管疾病，有较高的病死率，多数TBAD具有起病急、发展快的特点。自1996年首例TBAD腔内修复术成功实施以来，TBAD的治疗由巨创转为微创，围术期病死率和并发症发生率均显著降低[1]。2008年，中华医学会外科学分会血管外科学组发布了《主动脉夹层腔内治疗指南》，对TBAD的病因、诊断和腔内治疗作出了相应的推荐[2]。经过十余年的发展，新的腔内技术和腔内器具逐渐广泛应用于临床实践，并产生了新的循证医学证据[3,4]。鉴于此，中华医学会外科学分会血管外科学组组织国内血管外科领域部分专家，参考最新临床研究尤其是基于我国病例的研究结果，结合临床实践，围绕TBAD的诊断和治疗讨论并制订本共识，旨在为其诊疗提供原则性指导和依据，协助临床医生决策。

# 1 定义、分型及分期

1.1 定义 典型的主动脉夹层（aortic dissection, AD)是由于各种原因导致的主动脉内膜撕裂，血液流入动脉壁间，主动脉壁分层、分离，血管腔被游离的内膜片分隔为真腔和假腔。主动脉内膜上的血流入口即为原发破口，在主动脉远端可有继发破口，使真假腔之间血流相通。假腔内可以是持续的血流灌注，也可因为血液淤滞导致血栓化。

1.2 分型 AD 的分型有助于指导临床治疗和评估预后。1965 年, DeBakey 等首次根据 AD 的破口位置和夹层累及范围将其分为 3 种类型(图 1)。① I 型: 原发破口位于升主动脉或主动脉弓, 夹层累及范围自升主动脉至腹主动脉。② II 型: 原发破口位于升主动脉, 夹层局限于升主动脉, 少数可累及主动脉弓。③ III 型: 原发破口位于左锁骨下动脉以远，夹层累及范围局限于胸降主动脉为Ⅲa型，夹层向远端累及腹主动脉为Ⅲb型。1970年，Daily等根据夹层累及的范围提出了更简便的Stanford分型，即将AD分为A型和B型：凡是夹层累及升主动脉的为Stanford A型，相当于DeBakey I型和Ⅱ型；夹层累及左锁骨下动脉以远的胸降主动脉及其远端者为Stanford B型，相当于DeBakey Ⅲ型（图1）。目前，上述两种分型在国际上应用最广泛。近年来，随着腔内治疗的发展，国内外学者提出了新的“非A非B”型夹层概念，即原发破口在弓部或B型夹层向近端累及弓部的AD，这是对Stanford分型的重要补充 $^{[5]}$ 。

![](images/378114bbf79a36bce32466f70b468a1383f5526bd538447a3abf50a86d34560b.jpg)

<details>
<summary>text_image</summary>

Stanford A
DeBakey II
Stanford A
DeBakey I
Stanford B
DeBakey III
</details>

图 1 主动脉夹层 DeBakey 分型和 Stanford 分型示意图

1.3 AD 解剖分型 由于 DeBakey 分型和 Stanford 分型方式无法明确夹层远端累及的范围,美国血管外科协会(Society for Vascular Surgery,SVS)和美国胸外科医师协会(Society of Thoracic Surgeon,STS)联合发布了新的 AD 解剖分型[6]。

1.3.1 夹层分区法 夹层分区法具体如图2所示[7]。0区：主动脉窦-升主动脉移行处至无名动脉开口远端；1区：无名动脉开口远端至左颈总动脉开口远端；2区：左颈总动脉开口远端至左锁骨下动脉开口远端；3区：左锁骨下动脉开口远端至左锁骨下动脉开口以远2 cm处；4区：左锁骨下动脉开口以远2 cm处至胸降主动脉中点（约T6水平）；5区：胸降主动脉中点(约T6水平)至腹腔干开口近端；6区：腹腔干开口近端至肠系膜上动脉开口近端；7区：肠系膜上动脉开口近端至高位肾动脉开口近端；8区：高位肾动脉开口近端至低位肾动脉开口远端；9区：低位肾动脉开口远端至主动脉分叉处；10区：主动脉分叉处至髂总动脉分叉处；11区：髂外动脉段；12区：髂外动脉以下。

![](images/90fcb6c922357957908eb756c24b044525bdc8acefa8f078bc95c981ac769311.jpg)

<details>
<summary>text_image</summary>

0
1 2 3
4
5
6
7
8
9
10
10
11
11
</details>

图 2 夹层分区示意图

1.3.2 解剖分型 解剖分型方法具体如下[6]：①夹层原发破口起自0区即为A型，远端累及的范围用区域命名，例如，A型夹层远端累及到9区，即命名为 $\mathrm{A}_{9}$ 。②原发破口起自1区及以远的即为B型，TBAD的命名包含近端和远端累及的范围，累及的形式包括假腔、血栓化的假腔和壁间血肿。例如，一个原发破口在3区，近端累及至1区，远端累及至9区，则命名为 $\mathrm{B}_{1,9}$ 。此命名方式不能确切表示破口在哪个区，只显示在近远端累及的范围内。而且特别将逆撕型A型命名为 $\mathrm{B}_{0,\mathrm{D}},0$ 即0区，D为远端累及到的区域，例如 $\mathrm{B}_{0,9}$ 即破口在 $1\sim 9$ 区，近端累及至0区，远端至9区。另外，腹主动脉的孤立性夹层按照此定义也归为TBAD。③对于原发破口不清楚的夹层，用I(indeterminate)表示，这些夹层往往累及0区，故无法直接归为B型。这类夹层的命名和A型一样，例如破口不清楚，远端累及至9区，即命名为 $\mathrm{I}_9$ 。新的解剖分型是对传统分型的细化，有助于患者的风险分层、治疗和预后。

1.4 分期 TBAD 的分期主要根据发病的时间。传统的分期曾以 14 d 为界，将 TBAD 分为急性期和慢性期[8], 发病时间 $\leqslant 14$ d为急性期, $>14$ d为慢性期。由于早期研究发现, TBAD发病 $14\mathrm{d}$ 后并发症发生率尤其是夹层破裂的发生率显著降低。但是, 随着影像学的进展, 研究发现, $>14$ d时夹层内膜片仍然较为薄弱, 且具有较好的可塑性[9]。因此, 提出了亚急性期的概念, 但对其明确的时间定义各不相同。DeBakey等根据主动脉壁炎性反应程度, 将2周至2个月定义为亚急性期。2010年, 美国心脏病协会 (American Heart Association, AHA) 指南推荐的TBAD分期方法为: 发病时间 $\leqslant 2$ 周为急性期; $2\sim 6$ 周为亚急性期; $>6$ 周为慢性期[10]。2014年, 欧洲心脏病协会 (European Society of Cardiology, ESC) 主动脉疾病诊断和治疗指南推荐的TBAD分期方法为: 发病时间 $\leqslant 14$ d为急性期; $14\sim 90$ d为亚急性期; $>90$ d为慢性期[11]。2020年, SVS推荐采用ESC指南的分期方法[6]。综上, 本共识推荐采用ESC指南的分期方法进行分期。

# 2 流行病学

目前,国内尚缺乏基于人群的 AD 流行病学数据。根据 2011 年中国健康保险数据,我国急性 AD 年发病率为 2.8/10 万,但考虑到保险行业数据覆盖面有限,且部分患者在入院前即死亡未能确诊,真实的发病率并不明确[12]。有研究结果显示,欧美国家 AD 的年发病率为 (2.6\~6.0)/10 万,其中冬季和春季发病率较高,夏季最低[13]。此外,急性主动脉夹层国际注册研究(The International Registry of Acute Aortic Dissection, IRAD) 结果显示,AD 患者的平均年龄为 63.1 岁,男性为主(约占 65%),其中 TBAD 占所有类型夹层的 33%[14]。而国内一项主动脉夹层注册研究(Sino-RAD)结果显示,患者平均年龄为 51.8 岁,较欧美国家低 10 岁左右,其主要原因可能在于国内的高血压控制率低于国外[15]。

# 3 病因和危险因素

目前,公认的 TBAD 病因和危险因素包括以下几点。①高血压:增加主动脉壁应力和剪切应力。根据 IRAD 的数据,急性 TBAD 合并高血压的比例为 80.9% $^{[14]}$ 。国内单中心 10 年回顾性研究结果显示,接受腔内治疗的 TBAD 患者有 66.2% 合并高血压 $^{[16]}$ 。②动脉粥样硬化:常见于高血压、高脂血症、吸烟的老年患者,主动脉管壁发生退行性变,结构紊乱,表面存在溃疡。③基因突变导致的主动脉疾病:主要是遗传性结缔组织病导致的主动脉壁结构异常,最常见的是马方综合征、Loeys-Dietz 综合征和 Ehlers-Danlos 综合征。其中,马方综合征的诊断需依据修订版 Ghent 标准，综合患者的临床特征、家族史和基因检测结果，单纯的原纤蛋白-1 基因突变不足以建立诊断 $^{[17]}$ 。Loeys-Dietz 综合征是以转化生长因子- $\beta$ 受体 1 或受体 2 亚单位杂合突变为特点的遗传性疾病，临床表现为眶距过宽、悬雍垂裂或腭裂，以及动脉扭曲三联征 $^{[18]}$ 。Ehlers-Danlos 综合征是编码Ⅲ型胶原蛋白的 COL3A1 基因突变导致，主要引起中动脉的夹层或破裂，也有主动脉受累的报道 $^{[18]}$ 。此外，家族性胸主动脉瘤和胸主动脉夹层也具有遗传倾向，最常见肌动蛋白 $\alpha2$ 基因突变(10%\~14%) $^{[19]}$ 。截至目前，至少有 29 个基因被证实与 TBAD 的发病相关，合并遗传性疾病的患者预后往往更差，并且同一种遗传性疾病内部也因基因突变类型不同而导致严重程度有所差别 $^{[20]}$ 。④创伤：主要包括钝性损伤和医源性损伤导致的主动脉内膜受损。⑤解剖变异：一些解剖变异具有高 AD 发病风险，例如二叶式主动脉瓣、邻近动脉导管的主动脉缩窄（AD 患者中约 2% 合并主动脉缩窄）、Kommerell 憩室（迷走锁骨下动脉起始段瘤样扩张） $^{[21]}$ 。

# 4 诊断

# 4.1 临床表现

4.1.1 疼痛 疼痛是 TBAD 患者最常见的初始症状, 常呈突发的“撕裂样”或“刀割样”难以忍受的锐痛。疼痛的部位可提示 TBAD 的累及范围, 包括胸部、背部、腹部或下肢。部分隐匿性 TBAD 患者可无明显的临床表现, 常为体检时意外发现。

4.1.2 灌注不良 TBAD 累及主动脉的分支血管可导致器官缺血或灌注不良，缺血的程度从轻度的狭窄至完全的闭塞。缺血的类型可分为：①静力型，即夹层累及分支血管开口，血流灌注减少，如合并血栓形成则进一步加重缺血。②动力型，即分支血管开口保持解剖完整性，但真腔受压或内膜瓣片在管腔内摆动、脱垂入分支血管开口，限制血流进入靶器官。③混合型，即静力型和动力型因素均存在。早期或轻度的缺血可无临床表现，仅在影像学上观察到分支血管显影不良或组织器官灌注减少。夹层若累及腹腔干、肠系膜上或肠系膜下动脉，可引起胃肠道缺血表现，如急腹症、肠坏死、黑便或血便，部分患者可有肝脏或脾脏梗死。夹层若累及一侧或双侧肾动脉，可出现血尿、无尿、肾功能衰竭。夹层若累及下肢动脉，可表现为典型的急性下肢缺血症状，包括疼痛、苍白、无脉、感觉障碍、运动异常。

4.1.3 心脏并发症 不同于 Stanford A 型夹层，

TBAD 出现心脏并发症的情况较少。若患者出现主动脉瓣关闭不全、急性心肌梗死或心包填塞的表现,提示 TBAD 可能进一步向升主动脉进展,严重者可出现心力衰竭。

4.1.4 神经系统并发症 包括脑卒中和脊髓缺血。与 Stanford A 型夹层相比，TBAD 出现脑卒中的风险明显更低。对于合并脑卒中的 TBAD 患者，需注意是否存在解剖变异，如主动脉弓型、迷走锁骨下动脉、左椎动脉起自主动脉弓。脊髓的血供有多个来源，椎动脉的分支在枕骨大孔处汇合形成脊髓前动脉向下走行，供应脊髓前 2/3 的血供。在胸、腰段，脊髓前动脉常消失或不连续，主要依赖肋间动脉或腰动脉的分支。其中最重要的是根大动脉，它是胸腰段脊髓前动脉的主要来源，通常起自 T8\~L2 段主动脉的左侧，对于高危患者，可以通过术前 CTA 评估与定位。脊髓远端最重要的血供来源于髂内动脉。若 TBAD 累及锁骨下动脉、根大动脉或髂内动脉，可出现脊髓缺血的表现，包括截瘫、下肢轻瘫、大小便失禁、肠道功能异常等。

4.1.5 破裂 患者可有失血性休克的表现，包括神志淡漠或昏迷、皮肤苍白、心动过速、呼吸急促、尿少、血压下降等。

4.1.6 其他 部分 TBAD 伴巨大夹层动脉瘤形成者, 可表现为相应的压迫症状, 如声音嘶哑、呼吸困难和咯血等。

# 4.2 体征

4.2.1 肢体血压异常 TBAD 若累及肢体血管, 可出现四肢血压差别较大(双上肢血压或上下肢血压有差别), 最常见夹层累及左锁骨下动脉导致双上肢血压差大, 易被误诊为低血压。对于 TBAD 患者, 需常规检测四肢血压, 以明确有无肢体缺血。若四肢血压均低, 则需排除有无 AD 破裂出血或心包填塞可能。

4.2.2 胸部体征 TBAD 大量渗出或破裂出血导致胸腔积液,多位于左侧胸腔,可出现气管向健侧移位,呼吸困难,胸部叩诊呈浊音或实音,呼吸音减弱。

4.2.3 腹部体征 TBAD 导致腹腔器官缺血时, 可出现腹膜炎体征, 表现为腹部广泛压痛、反跳痛及肌紧张, 腹腔穿刺可见血性液体。

4.2.4 心脏查体 AD 所致急性主动脉瓣反流，听诊可有主动脉瓣区舒张期杂音。若出现心脏压塞，可有动脉血压持续下降，静脉压升高，心音遥远，心率增快，脉搏细弱。

4.2.5 神经系统体征 脑供血障碍时，可有神志淡漠、嗜睡、昏迷或偏瘫；脊髓缺血时，可有截瘫、大小便失禁等。

4.3 实验室检查 对于胸痛且怀疑 AD 的患者，入院后应完善血常规、血生化、肝肾功能、电解质、心肌酶谱、出凝血、D-二聚体、C-反应蛋白、血气分析等检查，有助于 AD 的鉴别诊断和明确有无合并症。当患者 D-二聚体升高，特别是短时间内快速升高时，拟诊 AD 的可能性增大，需与肺栓塞做鉴别诊断，D-二聚体可作为急性 AD 诊断的排除指标 $^{[22]}$ 。须注意，D-二聚体阴性也不能排除穿透性溃疡和壁间血肿的可能性。虽然有既往研究结果显示一些内皮细胞、平滑肌细胞以及血管间质受损相关的蛋白有助于 TBAD 的诊断和评估，但目前临床尚无针对 TBAD 的特异性生物标记物 $^{[23,24]}$ 。

4.4 影像学检查 TBAD 的影像学检查目的主要是为了综合评估整个主动脉，并且进行术前规划。具体的评估内容包括：①明确内膜片，识别真腔与假腔。②明确破口的位置和数目，包括原发破口和继发破口，以及夹层累及的范围。③明确主动脉分支血管的受累情况，血流是否通畅，有无狭窄或闭塞。④识别主要器官的显影情况。⑤明确有无心包积液、胸腔积液。⑥识别主动脉周围有无大量渗出、潜在出血情况。⑦明确假腔血栓化情况，识别内膜片是否增厚、僵硬，管壁有无钙化。⑧测量主动脉直径，原发破口与弓上分支的距离。⑨评估双侧髂动脉(腔内治疗的入路血管)的直径、夹层累及情况以及扭曲程度。

4.4.1 超声心动图 经胸超声心动图(transthoracic echocardiography, TTE)具有较好的便携性和普及性,诊断 AD 主要依赖于内膜片的检出,同时可以评估患者的心功能、主动脉瓣和主动脉窦的情况。TTE 诊断 AD 的准确率低于 CT 或 MRI,尤其是对于 TBAD, TTE 诊断的敏感度较低。此外,TTE 受限于患者的胸壁形态、肋间隙宽度、肥胖、肺气肿以及机械通气等,而经食管超声心动图(transesophageal echocardiography, TEE)可克服这些问题,明显提高诊断的准确率。但是,作为一种侵入性检查,TEE 对急性 AD 患者具有一定的风险,不建议在非全麻状态下实施该检查。目前,TEE 诊断 AD 的敏感度达到 99%,特异度约 89%,其优点在于可以探及原发破口和继发破口,明确血流方向,评估真腔与假腔之间的压力梯度,识别真腔闭塞[25]。

4.4.2 CTA 目前, CTA 是可疑 AD 患者的首选影

像学检查方法,具有普及性广、快速采集、敏感度和特异度高,空间分辨率高、多种后处理方式等优势 $^{[26]}$ 。但须注意以下几点:①采集范围从胸廓入口至耻骨联合水平,上至弓上三分支,下至双侧股动脉。②注射造影剂之前的平扫有利于评估主动脉管壁钙化,识别壁间血肿。③推荐采用64排以上心电门控CT扫描,以减少心脏和主动脉搏动所致的伪影。④注意静脉造影剂的量和注射速率,以减少左头臂静脉、上腔静脉增强影对主动脉的干扰。⑤如需评估主要器官的灌注,可延迟60\~90 s扫描静脉期。⑥多角度多平面三维重建有利于评估主动脉的形态,基于中心线的直径测量更为准确。⑦薄层扫描时,建议层厚<0.6 mm,以获取更多的影像学信息。

4.4.3 MRI 对于碘过敏、甲状腺功能亢进、肾功能不全、妊娠期妇女（妊娠早期 3 个月）或其他 CTA 相对或绝对禁忌证的患者，MRI 是首选的替代检查手段。MRI 对 AD 的诊断效率与 CTA 相似。相比于 CTA，MRI 具有更强的软组织分辨力，能够定性或量化功能参数。对于合并血管炎的患者，MRI 能够提供更好的管壁成像。但是，MRI 扫描时间长，不适用于循环不稳定的急症患者。此外，对于体内有生命辅助装置或磁性金属植入物、存在幽闭恐惧症的患者亦不适用。

4.4.4 血管造影 血管造影曾被认为是 AD 诊断的“金标准”。但实际上，血管造影在显示内膜片、内膜破口、真假两腔方面并不优于 CTA。由于是一种侵入性有创操作，血管造影已不再作为 AD 的常规诊断检查手段。但是，血管造影在动态显示累及分支动脉以及血流方向方面仍有一定优势。

4.4.5 血管腔内超声 血管腔内超声可以实时、动态地显示主动脉腔内的三维结构。对于复杂的TBAD,血管腔内超声有助于区分真腔和假腔,尤其是主动脉双腔之间的存在广泛交通、真腔完全压闭的患者。血管腔内超声对AD诊断的敏感度和特异度优于TEE。但作为一项侵入性检查,血管腔内超声主要用于术中指引。

# 4.5 诊断

4.5.1 诊断流程 对于急性胸痛的患者,2010年AHA指南提出了疑似AD的高危易感因素、疼痛表现和体征(表1) $^{[10]}$ 。对于存在表1中高危因素、症状和体征的初诊患者,应考虑AD可能并安排合理的检查以明确诊断,具体的诊断流程如图3所示 $^{[27]}$ 。须注意,该诊断流程仅适用于AD,须与其他初始表现为胸腹痛的疾病相鉴别。

表 1 疑似 AD 的高危因素,疼痛表现和体征

<table><tr><td>高危因素</td><td>典型疼痛表现</td><td>体征</td></tr><tr><td>马方综合征或其他结缔组织病</td><td>胸、背或腹痛有以下特点:</td><td>动脉搏动消失或无脉</td></tr><tr><td>主动脉疾病家族史</td><td>急性发作</td><td>四肢血压差异大</td></tr><tr><td>主动脉瓣疾病史</td><td>剧烈疼痛,难以忍受</td><td>局灶性神经功能缺失</td></tr><tr><td>胸主动脉瘤病史</td><td>撕裂样或刀割样锐痛</td><td>新发主动脉瓣舒张期杂音</td></tr><tr><td>主动脉干预或心脏手术史</td><td></td><td>低血压或休克</td></tr></table>

![](images/3ab446f9087e9d28d7d6e231386f2eb103f594e9ecdc43975ea4934647f768d2.jpg)

<details>
<summary>flowchart</summary>

```mermaid
graph TD
    A["疑似AD的急性胸痛患者"] --> B["病史、体征+心电图+实验室检查"]
    B --> C["可否立即行CTA或MRI检查"]
    C -->|否| D["TTE"]
    C -->|可| E["CTA/MRI"]
    D --> F["排除AD"]
    D --> G["疑似或明确AD"]
    E --> H["明确AD"]
    E --> I["排除AD"]
    H --> J["A型AD"]
    H --> K["B型AD"]
    J --> L["有无破裂征象，器官灌注不良，器官功能评价"]
    K --> L
```
</details>

图 3 主动脉夹层的诊断流程

4.5.2 TBAD 的分类 在明确 TBAD 的诊断后, 还需根据患者的临床表现和影像学特征进行细分 $^{[6]}$ 。见表 2。

表 2 各型主动脉夹层的临床表现和影像学特征

<table><tr><td>非复杂型</td><td>高危型</td><td>复杂型</td></tr><tr><td>无破裂征象</td><td>不可缓解的疼痛</td><td>破裂或先兆破裂</td></tr><tr><td>无灌注不良</td><td>无法控制的高血压</td><td>灌注不良综合征</td></tr><tr><td>无高危因素</td><td>血性胸腔积液</td><td></td></tr><tr><td></td><td>主动脉直径&gt;40 mm</td><td></td></tr><tr><td></td><td>假腔直径&gt;22 mm</td><td></td></tr><tr><td></td><td>单纯影像学发现的灌注不良</td><td></td></tr><tr><td></td><td>小弯侧的原发破口</td><td></td></tr><tr><td></td><td>再入院</td><td></td></tr></table>

虽然无破裂或灌注不良征象的非复杂型TBAD患者一般不会立即威胁生命，但是一部分存在高危因素的患者往往预后较差。高危型TBAD是指存在不可缓解的疼痛、无法控制的高血压、血性胸腔积液、主动脉直径>40 mm、假腔直径>22 mm、单纯影像学检查发现的灌注不良、小弯侧的原发破口以及再入院中任意一项高危因素的患者。其中，不可缓解的疼痛定义为尽管予以足量的降压、止痛、抗焦虑治疗，患者仍诉剧烈疼痛且持续时间>12 h。无法控制的高血压定义为超过3种不同类型的降压药按最大推荐或耐受剂量给药，患者仍有高血压且持续时间>12 h。在肾灌注不良方面，需观察患者的尿量以及血肌酐水平，单纯的血肌酐水平增高影响的因素有多种，放射性同位素肾图可明确特定一侧肾脏的灌注，对急性肾损伤患者的评估推荐采用急性肾损伤网络分期量表(AKIN)。对于脑卒中的评估，可采用改良Rankin量表，而脊髓损伤的评估则选用改良Tarlov评分系统。

4.5.3 诊断的完整性 TBAD 患者的合并症对其治疗和结局具有十分重要的影响,入院时需明确患者有无心力衰竭(新发或既往史)、慢性阻塞性肺疾病、高血压、慢性肾病、外周动脉疾病、脑血管疾病以及冠心病。既往如有主动脉、结构性心脏病、冠心病相关的手术史也应记录。此外,对于有胸主动脉疾病家族史的患者,需警惕前述遗传因素导致的主动脉疾病。

# 5 治疗

5.1 初始治疗原则 一旦明确诊断后，不论何种类型的 AD 均应立即给予药物治疗，其目的是镇静、镇痛、降低心率和血压、防止夹层进一步扩展或破裂。同时，应注意全面评估患者一般情况，嘱患者卧床休息，并进行心电监护。如合并其他复杂情况，必要时应将患者送入 ICU。

5.1.1 镇静镇痛 根据疼痛程度及体重，可选用阿片类药物(哌替啶或吗啡)，一般哌替啶 100 mg 或吗啡 5\~10 mg 静脉注射，必要时可予每 6\~8 h 给药 1 次或请麻醉科会诊。镇痛可以降低交感神经兴奋导致的心率和血压上升。

5.1.2 控制血压 根据入院时的血压情况，选用不同的降压方案，但应保证能够维持最低的有效终末器官灌注，尿量应保持在>30 ml/h。静脉用β受体阻滞剂(如美托洛尔、艾司洛尔等)或α受体阻滞剂(如乌拉地尔等)是最基础的药物治疗。对于降压效果不佳者，可联用一种或多种降压药，如钙离子通道阻滞剂(尼卡地平、地尔硫草等)。血压控制的目标是将收缩压降至100\~130 mmHg（1 mmHg=0.133 kPa）、平均动脉压维持在60\~70 mmHg为宜。

5.1.3 降低左心收缩力与收缩速率 心率控制的目标在 60\~80 次/min。在心率未得以控制前，单纯使用血管扩张剂可引起反射性儿茶酚胺释放，增加左心室收缩力，导致主动脉壁剪切应力升高，引起夹层恶化。

# 5.2 急性或亚急性 TBAD 的治疗

5.2.1 治疗原则 药物治疗是 TBAD 患者的基本治疗方式。在充分的药物治疗基础上，对于急性复杂型 TBAD 患者，需尽早行手术干预。目前，随着腔内技术的成熟和器械的进步，腔内治疗已取代开放手术成为首选治疗方式。而对于急性非复杂型 TBAD 患者，一般药物保守治疗的病死率较低。但 INSTEAD 研究的 5 年随访结果显示，腔内治疗具有较单纯药物治疗更优的主动脉重构，且具有降低远期主动脉相关不良事件风险的潜力 $^{[9]}$ 。此外，国内研究的长期随访结果证实，对于急性非复杂型 TBAD，与单纯药物治疗相比，行胸主动脉腔内修复术 (thoracic endovascular aortic repair, TEVAR) 治疗的主动脉相关不良事件风险和病死率更低 $^{[28]}$ 。随着临床经验的积累，国内外学者从急性非复杂型 TBAD 中细分出一个亚组，即急性高危型 TBAD $^{[6]}$ 。急性高危型 TBAD 患者虽然短期内死亡风险较低，但是单纯药物治疗的预后往往较差。对于这部分合并高危因素的患者,推荐首选 TEVAR。对于无高危因素的急性非复杂型 TBAD,目前最佳治疗方案依然存在争议,但本共识讨论专家推荐选择腔内治疗,以改善其远期主动脉重构,降低主动脉相关不良事件的发生风险。当然,这一推荐仍需更多高质量前瞻性 RCT 研究证据支持。

5.2.2 腔内治疗 TEVAR 的原理是采用腔内移植物覆盖原发破口,使血液流向真腔,重塑真腔,改善远端器官、肢体血供,促进假腔血栓化和主动脉重构。单纯 TEVAR 适用于锚定区充足(原发破口距离左锁骨下动脉开口>1.5 cm)、非遗传性结缔组织病性 TBAD。值得注意的是,锚定区不足(<1.5 cm)和遗传性结缔组织病并非 TEVAR 的绝对禁忌证。

国内的 Meta 分析结果显示,TEVAR 治疗急性或慢性 TBAD 的手术成功率为 99.1%,院内病死率为 1.6%,具有较好的短期疗效[29]。实施 TEVAR 过程中,仍有一些技术细节和操作规范需注意。①麻醉:由于术中需要大幅度调控血压,同时避免因疼痛不适导致的血压增高,建议首选全身麻醉。但是,对于麻醉风险较高,呼吸功能差,血流动力学不稳以及紧急病情的患者,可使用局麻。此外,局麻有助于术中的神经功能监测。②干预时机:对于急性复杂型或病情恶化的急性高危型 TBAD,需要急诊积极治疗;对于急性非复杂型 TBAD,在亚急性期干预的疗效更佳[30];对于稳定的急性高危型 TBAD 患者,需动态监测,尽早干预。③支架放大率的选择:不同品牌支架对支架放大率有不同的要求,需要足够的径向支撑力以保证移植物与主动脉壁之间紧密贴合减少内漏,也要避免过度扩张损伤主动脉内膜导致新发破口;同时,应尽可能避免球囊后扩。④造影:全主动脉分段造影,主动脉弓部采用左前斜位以最大程度展开弓部,具体角度可依据术前 CTA 的测量结果,远端腹主动脉段采取正位在 T12 水平造影,以观察重要器官的血供情况;髂动脉推注造影剂明确导丝导管循真腔上行;必要时主动脉弓上分支血管造影评估双侧椎基底动脉。⑤入路血管的选择:首选股动脉,术前需在影像学上评估股动脉的直径和扭曲程度,选择更易进入真腔的一侧作为入路血管。⑥血压控制:在支架释放时,如有必要,建议将平均动脉压控制在 100 mmHg 左右,有助于支架精准锚定。

5.2.3 近端锚定区延伸 对于近端锚定区不足 (<1.5 cm) 的患者, 直接覆盖左锁骨下动脉具有潜在的神经系统并发症和远期左锁骨下动脉窃血的风险。随着腔内技术的发展和器具的进步,对于近端锚定区不足或锚定区不良,左锁骨下动脉受累,非A非B型主动脉夹层患者,可以考虑近端锚定区延伸技术,主要包括以下几种:①分支支架技术:目前,分支支架主要包括正向和逆向血流的大弯侧分支支架。单分支支架已被批准用于临床实践,国内多中心研究结果显示,对于左锁骨下动脉受累的TBAD患者,采用单分支支架的技术成功率为97%,内漏发生率为5%,6年随访病死率为7%,单分支通畅率为93% $^{[31]}$ 。②开窗技术:目前,开窗技术包括原位开窗和体外开窗两种。国内多中心回顾性研究证实,体外开窗技术治疗主动脉弓部病变安全、有效,技术成功率为98.6%,2年生存率为94.9%,免于再干预率为93.1%,该技术对支架的精准释放要求较严苛 $^{[32]}$ 。原位开窗技术(包括针刺开窗和激光开窗)避免了支架输送过程中的角度改变,但需注意术中脑保护 $^{[33-37]}$ 。这两种技术术前均应详细评估分支血管的直径、扭曲程度。③平行支架技术:是由烟囱、潜望镜和三明治技术发展而来。平行支架技术的优势在于分支支架和主体均已商品化,无需订制,急诊状况下也可获得,且可以作为弓上分支误差以后的补救措施。但是,由于分支支架和主体之间存在一个漏隙,术后出现Ia型内漏的风险较高,并且分支支架数量越多,与主体支架并行距离越短,Ia型内漏风险越高。国内学者的Meta分析结果显示,烟囱技术应用于主动脉弓部的围术期内漏发生率为21%,分支血管的通畅率为93% $^{[38]}$ 。④复合手术:采用解剖外途径,即头臂血管间转流的方法,可以在不开胸、不阻断主动脉、不使用体外循环、无需低温停循环的情况下,拓展近端锚定区。而解剖学途径,即升主动脉至头臂血管的转流,需要开胸,但无需阻断主动脉和体外循环。开放手术和腔内治疗可分期,也可一期进行。

总之,这些技术减小了创伤,为不能耐受开放手术的患者提供了切实可行的替代方案。但新技术的开展必须得到患者及其家属充分的知情同意。此外,脑卒中仍然是其主要并发症,其潜在的机制包括频繁的弓上操作导致的管壁动脉粥样硬化斑块脱落、输送系统释放的空气栓塞以及弓上分支血管的丢失。

5.2.4 开放手术 开放手术因创伤大，围术期并发症发生率和病死率高，目前已不作为非遗传性结缔组织病的急性或亚急性 TBAD 患者的首选治疗方式。对于合并主动脉根部疾病、升主动脉病变，或其他需要外科干预的心脏疾病的 TBAD 患者, 可一期采用术中支架象鼻手术, 也可先行 TEVAR, 二期处理其他合并症。支架象鼻手术的优势在于其对遗传性结缔组织病导致的 TBAD 也适用。

5.2.5 远端破口的处理 临床实践中，大多数TBAD患者不止一个破口。夹层内膜片在向远端发展过程中可形成多个继发破口，尤其是遇到较大的分支血管时内膜可从分支血管开口处断裂。从病理生理学角度分析，远端继发破口通常是夹层假腔的出口，使假腔压力得以稳定。对于急性或亚急性TBAD患者，近端原发破口隔绝后，通常不处理远端继发破口。目前，是否一期处理远端破口以及如何处理尚无定论。对于腹腔干动脉以上的继发破口，若破口较大或反流量较大者，可一期修复，但需注意发生脊髓缺血的风险较高。至于二期处理远端破口的指征以及如何处理仍在探索阶段，尚缺乏相关证据。

5.2.6 内脏或肢体缺血的管理 主动脉分支血管的受累机制分为动力型、静力型和混合型3种。其中，动力型阻塞患者在夹层近端破口修复后，真腔血流恢复，压力增高、管腔扩大，大多可自发缓解。静力型阻塞患者又可分为真腔供血、假腔供血和真假两腔供血3类。其中，真腔供血和真假两腔供血在夹层术后短期一般不会出现严重的器官或肢体缺血，远期结果受到血管阻塞的程度、夹层重构等因素的影响。而部分假腔供血型患者术后出现器官严重缺血的风险较高，必要时需行支架植入或血管旁路术重建分支血管血供。须注意，目前对于内脏器官或肢体缺血的治疗争议较多。临床上，应根据患者的症状、缺血的程度和类型以及距离初次干预的时间进行个体化治疗。

5.3 慢性 TBAD 慢性 TBAD 一般较为稳定,其治疗措施主要是控制血压和定期影像学随访。慢性 TBAD 的手术干预指征包括: ①夹层动脉瘤形成。欧洲开放性手术的标准为直径>5.5 cm, 考虑到腔内治疗的获益, 以及亚洲人群血管直径相对较细,该指征可适当放宽。②夹层直径快速增大 (>10 mm/年)。③疼痛无法缓解。④夹层破裂或先兆破裂。⑤主动脉分支血管严重缺血。目前,在慢性 TBAD 患者中,尚缺乏比较开放手术和 TEVAR 的前瞻性 RCT 研究。一项 Meta 分析结果显示,TEVAR 治疗的围术期病死率和并发症发生率低于开放手术,中期随访两组间生存差异无统计学意义,但开放手术组再干预率和破裂风险低于 TEVAR 治疗组 $^{[39]}$ 。因此，两种手术方式各有利弊，重点在于患者的选择。

# 5.4 特殊类型的 TBAD

5.4.1 壁间血肿 壁间血肿是以主动脉管壁中膜环形或新月形高密度影、管壁增厚(>5 mm)为特点的主动脉急症,其与典型的TBAD的区别在于无明显的内膜破口或假腔形成,在平扫CT上显示最清楚,二者不容易鉴别,常合并存在。壁间血肿形成的潜在机制包括:主动脉滋养血管自发性破裂、出血,导致管壁内血肿形成;管壁的微小破口引起的血栓化夹层。通常,壁间血肿的患者经过充分的降压治疗后可自发缓解,但仍需严密随访。如果主动脉管壁持续增厚,管径扩大,或出现穿透性溃疡,或进展形成典型的TBAD,则需积极地行腔内治疗。

5.4.2 穿透性溃疡 穿透性溃疡是指主动脉粥样硬化斑块溃疡穿透内弹力膜达管壁中膜，常合并壁间血肿。约 $20\%$ 的穿透性溃疡无相关的壁间血肿，可能是因为慢性动脉粥样硬化病变所致的中膜纤维化[40,41]。患者如有剧痛，常提示溃疡穿透较深，可达外膜层，破裂风险较高。在平扫CT上，穿透性溃疡与壁间血肿相似，而增强CT则表现为穿透钙化斑块的造影剂外渗。穿透性溃疡的治疗以充分降压为基础，目的在于预防主动脉破裂或进展成急性TBAD。手术干预的指征包括无法缓解的疼痛、合并壁间血肿和先兆破裂。如快速增大的主动脉溃疡、主动脉旁血肿、胸腔积液等，治疗上首选TEVAR。

5.4.3 创伤性夹层 创伤性 TBAD 属于急症,常合并多发伤,24 h 病死率高,其治疗需多学科综合治疗协作组(multi-disciplinary team,MDT)评估。若 TBAD 为主要损伤,则优先治疗 TBAD,首选急诊 TEVAR 治疗;若合并其他重要器官损伤,建议在血流动力学稳定或其他致命性损伤修复后,尽早治疗 TBAD,仍然首选TEVAR。

5.4.4 医源性夹层 较少见，常见于导管相关的冠脉介入操作、心脏手术、主动脉腔内治疗、经股动脉入路的主动脉瓣置换等导致的主动脉损伤。治疗原则一般视损伤部位、范围而定。如果是腹主动脉损伤导致的局限性夹层，优先选择药物保守治疗；如果是胸降主动脉损伤导致的 TBAD，可行 TEVAR 治疗。

5.4.5 合并妊娠 非常罕见，目前的治疗经验仅限于个案报道。治疗原则为孕周<28 周且孕妇无主动脉先兆破裂、不可控制的高血压、无法缓解的疼痛、主动脉瘤变、胎儿窘迫等急症，可先行药物保守

治疗；若孕周>32 周，可先行剖宫产后再治疗 TBAD，治疗原则参见急性 TBAD 的治疗；孕周为 28\~32 周时，可视病情行保胎或剖宫产，然后积极治疗 TBAD。

5.4.6 合并大动脉炎 大动脉炎导致的 TBAD 较少见，治疗原则是在控制动脉炎的基础上，首选 TEVAR 治疗。若大动脉炎处于活跃期，原则上先行免疫治疗，必要时也可先行 TEVAR 治疗，而开放性手术后发生吻合口漏的风险较大。

# 5.5 术后常见并发症的预防和处理

5.5.1 内漏 内漏是夹层 TEVAR 术后常见并发症，是指血液从各种不同的途径继续流入假腔，包括覆膜支架与主动脉壁之间，肋间动脉反流，分支动脉受累，支架织物破损或渗漏，以及没有封闭的远端破口。其中，以近端 I 型内漏最多见，锚定区过短或覆膜支架头端与主动脉壁贴合不严导致血液从两者的间隙进入原发破口，是 I 型内漏形成的主要原因。术中少量的内漏无需即刻处理，随后多可自行消失，但需严密随访；术中较大的内漏应积极处理，可植入 1 枚短段覆膜支架隔绝近端内漏，尽可能避免球囊扩张。目前，对于内漏量多少的判断尚无量化的指标，仍需依靠术者经验，而近端足够的锚定区是避免内漏的关键。

5.5.2 支架源性新发破口（stent graft-induced new entry, SINE）SINE 是 TBAD 患者 TEVAR 术后的重要并发症，定义为排除疾病自然进展或腔内操作损伤所致，发生于支架两端与主动脉接触部位的新破口 $^{[42]}$ 。根据发生于支架的近端和远端，分别称为近端 SINE 和远端 SINE $^{[43, 44]}$ 。①近端 SINE：近端 SINE 多发展为逆行性 A 型夹层（retrograde type A dissection, RTAD），是 TEVAR 术后最严重的并发症之一，发生率约 2.2%，可导致夹层破裂、心包填塞等，病死率高达 37.1% $^{[45, 46]}$ 。RTAD 可能与主动脉管壁本身的病变（如遗传性结缔组织病）、急性期管壁水肿、锚定区不良、支架弹性回直力和支架管径放大率偏大等因素相关。RTAD 可发生于术中即刻、围术期或随访期间，一经发现需立即按 A 型夹层进行处理。②远端 SINE：远端 SINE 发生率约为 7.9%，在慢性期 TBAD 中的发生率（12.9%）远高于急性期 TBAD（4.3%），患者通常无明显的症状，常在术后 12\~36 个月通过影像学随访发现 $^{[47]}$ 。远端 SINE 的发生与支架管径放大率密切相关，其治疗主要是再次行 TEVAR 以覆盖新发破口，减小假腔血流压力，需注意植入的新的覆膜支架与前一枚支架的重叠距离应依据不同品牌、形态、尺寸支架的要求，以避免发生内漏。因此，选择合适的支架尺寸十分关键，倒锥形支架、Petticoat技术以及远端限制性支架技术或能降低远端SINE风险。Petticoat技术是指在近端覆膜支架的远端植入裸支架，以扩大真腔，使血流进入内脏动脉，同时为胸腹主动脉内膜提供支撑。远端裸支架选用径向支撑力较小的自膨式裸支架，对内膜损伤较小。远端限制性支架技术是指通过先释放径向支撑力大但口径小的远端裸支架或覆膜支架延长支，以降低覆膜支架远端直径放大率。

5.2.3 其他原因引起的 RTAD 虽然 SINE 是引起 RTAD 的最主要因素，约占所有 RTAD 的 80%，但仍有 10%\~20% 的 RTAD 并非 SINE 所致，而是由病程进展自发形成升主动脉新破口，或是弓上操作不当等医源性损伤引起(导丝、导管、球囊扩张等)。该类型的 RTAD 破口往往与覆膜支架近端存在一定的距离。在主动脉的介入手术过程中，应尽可能动作轻柔，减少或避免球囊后扩。

5.2.4 脑卒中 脑卒中定义为局部或广泛的神经功能受损且持续时间>24 h，也包括 CT 或 MRI 证实的无症状脑梗死。夹层术后脑卒中的发生率为1%\~3%，可能与主动脉弓部或头臂血管开口处操作时斑块或附壁血栓脱落、左椎动脉优势的左锁骨下动脉被覆盖、迷走椎动脉、术中控制性低血压时间过长、空气栓塞等因素相关。针对上述危险因素的预防可降低脑卒中风险。值得注意的是，术前对弓上分支和脑部血管及循环状况的评估尤为重要。此外，对于弓上分支的操作，术中需注意脑保护，有条件者可以进行脑氧监测。

5.2.5 截瘫 夹层 TEVAR 术后截瘫与根大动脉或左锁骨下动脉覆盖、术中控制性低血压时间过长有关，通常表现为术后下肢活动障碍。一旦出现，需尽快行脑脊液测压引流，维持脑脊液压力在 8\~10 mmHg。此外，由于脊髓的灌注压是平均动脉压与脑脊液压力的差值，还可采用提高动脉压的方式。其他治疗方式包括适当抗凝、应用糖皮质激素等。对于截瘫高危患者，例如需长段覆盖主动脉、破口位于降主动脉中下段而需覆盖部分或全部 T8\~L1 节段（约 75% 的根大动脉发自该节段）、既往腹主动脉腔内或开放手术史、全身低血压等，术前可以考虑预防性脑脊液引流，术中应保留或重建左锁骨下动脉，避免全身低血压，注意 MDT 合作。

5.2.6 远端胸腹主动脉夹层动脉瘤 急性或亚急

性 TBAD 患者行 TEVAR 主要有利于支架覆盖段以及部分邻近胸降主动脉的重构。IRAD 研究结果显示, TBAD 患者 TEVAR 术后 5 年主动脉扩张或远端胸腹主动脉夹层动脉瘤形成比例为 62.7% $^{[48]}$ 。目前，远端胸腹主动脉夹层动脉瘤的治疗方式较多, 包括开放手术、复合手术、开窗或分支支架技术、假腔填塞等, 但最佳的干预方式尚无定论 $^{[49,50]}$ 。有研究结果显示, 初次手术采用 Petticoat 技术可有助于远端主动脉的重构 $^{[51]}$ 。

# 6 随访管理

6.1 随访原则 TBAD 患者无论采用何种治疗方式,均需长期乃至终身进行规律随访。即使手术后康复出院的患者也存在新发夹层、器官缺血、夹层动脉瘤形成或破裂的风险。规律的随访有助于定期监测夹层的形态变化、主动脉重构情况、器官功能(尤其是肾功能)以及发现潜在影响预后的危险因素,为调整用药和及时再干预提供依据,以达到改善患者远期预后的目的。

6.2 影像学随访 如无禁忌，影像学随访应首选CTA，也可行DSA下主动脉造影，评估的内容包括假腔血栓化、主动脉直径、假腔血流方向、支架位置形态、“鸟嘴”征等。CTA检查时建议采集3个期相：平扫期、动脉期和延迟期。平扫CT有助于评估钙化病变和金属支架，发现壁间血肿。延迟期一般建议延迟300 s，有助于评估器官灌注、假腔通畅性和假腔血流方向。其中，假腔血栓化是管腔增大和再干预的重要预测因素，包括假腔持续灌注、部分血栓化和完全血栓化，需标明观察的节段。每次随访应对比前后两次CTA的结果以评估夹层进展，主动脉重构以及主动脉增大的情况，必要时尽早干预。目前，影像学随访的频率尚无统一标准，本共识推荐术后3、6、12个月及以后每年1次影像学随访。对于持续稳定时间>5年的患者，可适当放宽至2\~3年随访1次。对于存在CTA禁忌证的患者，可行MRI随访。

6.3 药物治疗 高血压是 TBAD 患者术后死亡的主要危险因素。本共识推荐的药物控制目标为血压 120/80 mmHg、心率 60\~80 次/min。 $\beta$ 受体阻滞剂是 TBAD 患者术后最常用的基础降压药物，其可能延缓残余夹层扩张、降低主动脉相关事件和改善患者远期生存。另外， $\beta$ 受体阻滞剂降压效果不佳时，可在专科医师的指导下联用血管紧张素转化酶抑制剂、血管紧张素Ⅱ受体拮抗剂及二氢吡啶类钙通道阻滞剂类等降压药物。

6.4 再干预 IRAD 研究报道, TBAD 腔内治疗后 5 年再次干预率约为 30.6% $^{[48]}$ 。TBAD 患者再次干预的指征包括 RTAD、严重内漏、残余夹层扩张 $\geqslant$ 5.5 cm 或扩张速度 $\geqslant$ 10 mm/年、新发破口导致假腔明显扩张、重要器官缺血、支架感染等。治疗方法有再次腔内修复术或开放手术等。

参与本共识编写及讨论专家名单（按姓氏汉语拼音排序）：陈忠(首都医科大学附属北京安贞医院)，戴向晨(天津医科大学总医院)，董智慧(复旦大学附属中山医院)，符伟国(复旦大学附属中山医院)，戈小虎(新疆维吾尔自治区人民医院)，谷涌泉(首都医科大学宣武医院)，郭平凡(福建医科大学附属第一医院)，郭曙光(中国人民解放军联勤保障部队920医院)，郭伟(中国人民解放军总医院)，郝斌(山西白求恩医院)，何菊(天津市第一中心医院)，黄建华(中南大学湘雅医院)，姜维良(哈尔滨医科大学附属第二医院)，金辉(深圳大学总医院)，金星(山东省立医院)，李雷(清华大学第一附属医院)，李晓强（南京大学医学院附属鼓楼医院），李拥军(北京医院)，李震(郑州大学第一附属医院)，刘冰(哈尔滨医科大学附属第一医院)，刘昌伟(北京协和医院)，刘鹏(中日友好医院)，陆信武(上海交通大学医学院附属第九人民医院)，曲乐丰(海军军医大学第二附属医院)，舒畅(中国医学科学院阜外医院)，覃晓(广西医科大学第一附属医院)，王豪夫(青岛大学附属医院)，王劲松(广东省人民医院)，吴丹明(辽宁省人民医院)，肖占祥(海南省人民医院)，辛世杰(中国医科大学附属第一医院)，闫波(银川市第一人民医院)，翟水亭(河南省人民医院)，张福先(首都医科大学附属北京世纪坛医院)，张鸿坤(浙江大学医学院附属第一医院)，张岚(上海交通大学医学院附属仁济医院)，张小明(北京大学人民医院)，章希炜(南京医科大学第一附属医院)，赵纪春(四川大学华西医院)，赵珺(上海交通大学附属第六人民医院)，周为民(南昌大学第二附属医院)

执笔者: 周旻(复旦大学附属中山医院), 符伟国(复旦大学附属中山医院)

# 参考文献

[1] DAKE MD, KATO N, MITCHELL RS, et al. Endovascular stent -graft placement for the treatment of acute aortic dissection[J]. N Engl J Med, 1999, 340(20): 1546-1552.   
[2] 中华医学会外科学分会血管外科学组. 主动脉夹层腔内治疗指南[J]. 中国实用外科杂志, 2008, 28(11): 909-912.  
[3] 郭伟, 刘峰, 葛阳阳. B型主动脉夹层腔内治疗共识与争议 [J]. 中国实用外科杂志, 2017, 37(12): 1339-1345.  
[4] 国家心血管病专家委员会血管外科专业委员会. 杂交技术治疗累及弓部主动脉病变的中国专家共识 [J]. 中国循环杂志, 2020, 35(2): 124-129.  
[5] CZERNY M, SCHMIDLI J, ADLER S, et al. Editor's Choice - current options and recommendations for the treatment of

thoracic aortic pathologies involving the aortic arch: An expert consensus document of the European Association for Cardio-Thoracic Surgery (EACTS) & the European Society for Vascular Surgery (ESVS)[J]. Eur J Vasc Endovasc Surg, 2019, 57(2): 165–198.   
[6] LOMBARDI JV, HUGHES GC, APPOO JJ, et al. Society for Vascular Surgery (SVS) and Society of Thoracic Surgeons (STS) reporting standards for type B aortic dissections [J]. J Vasc Surg, 2020, 71(3): 723–747.   
[7] FILLINGER MF, GREENBERG RK, MCKINSEY JF, et al. Reporting standards for thoracic endovascular aortic repair (TEVAR)[J]. J Vasc Surg, 2010, 52(4): 1022–1033.   
[8] HIRST AE JR, JOHNS VJ JR, KIME SW JR. Dissecting aneurysm of the aorta: A review of 505 cases [J]. Medicine (Baltimore), 1958, 37(3): 217–279.   
[9] NIENABER CA, KISCHE S, ROUSSEAU H, et al. Endovascular repair of type B aortic dissection: Long-term results of the randomized investigation of stent grafts in aortic dissection trial [J]. Circ Cardiovasc Interv, 2013, 6(4): 407–416.   
[10] HIRATZKA LF, BAKRIS GL, BECKMAN JA, et al. 2010 ACCF/AHA/AATS/ACR/ASA/SCA/SCAI/SIR/STS/SVM guidelines for the diagnosis and management of patients with thoracic aortic disease: A report of the American College of Cardiology Foundation/American Heart Association Task Force on Practice Guidelines, American Association for Thoracic Surgery, American College of Radiology, American Stroke Association, Society of Cardiovascular Anesthesiologists, Society for Cardiovascular Angiography and Interventions, Society of Interventional Radiology, Society of Thoracic Surgeons, and Society for Vascular Medicine[J]. Circulation, 2010, 121(13): e266–e369.   
[11] ERBEL R, ABOYANS V, BOILEAU C, et al. 2014 ESC guidelines on the diagnosis and treatment of aortic diseases: Document covering acute and chronic aortic diseases of the thoracic and abdominal aorta of the adult. The Task Force for the Diagnosis and Treatment of Aortic Diseases of the European Society of Cardiology (ESC) [J]. Eur Heart J, 2014, 35(41): 2873–2926.   
[12] XIA L, LI JH, ZHAO K, et al. Incidence and in-hospital mortality of acute aortic dissection in China: Analysis of China Health Insurance Research (CHIRA) Data 2011 [J]. J Geriatr Cardiol, 2015, 12(5): 502–506.   
[13] HOWARD DP, BANERJEE A, FAIRHEAD JF, et al. Population-based study of incidence and outcome of acute aortic dissection and premorbid risk factor control: 10-year results from the oxford vascular study [J]. Circulation, 2013, 127(20): 2031-2037.   
[14] PAPE LA, AWAIS M, WOZNICKI EM, et al. Presentation, diagnosis, and outcomes of acute aortic dissection: 17-year trends from the international registry of acute aortic dissection [J]. J Am Coll Cardiol, 2015, 66(4): 350–358.   
[15] 中国心血管健康与疾病报告编写组. 中国心血管健康与疾病报告 2020 概要 [J]. 中国循环杂志, 2021, 36(6): 521-545.

[16] HUANG L, KAN Y, ZHU T, et al. Ten-year clinical characteristics and early outcomes of type B aortic dissection patients with thoracic endovascular aortic repair [J]. Vasc Endovascular Surg, 2021, 55(4): 332–341.   
[17] LOEYS BL, DIETZ HC, BRAVERMAN AC, et al. The revised Ghent nosology for the Marfan syndrome [J]. J Med Genet, 2010, 47(7): 476–485.   
[18] GOYAL A, KERAMATI AR, CZARNY MJ, et al. The genetics of aortopathies in clinical cardiology [J]. Clin Med Insights Cardiol, 2017, 11: 1179546817709787.   
[19] 杨锦, 李昭辉, 周建, 等. 家族性胸主动脉瘤及主动脉夹层突变基因的研究进展 [J/CD]. 中国血管外科杂志（电子版), 2020, 12(4): 348-352.  
[20] BROWNSTEIN AJ, ZIGANSHIN BA, KUIVANIEMI H, et al. Genes associated with thoracic aortic aneurysm and dissection: An update and clinical implications [J]. Aorta (Stamford), 2017, 5(1): 11–20.   
[21] TANAKA A, MILNER R, OTA T. Kommerell's diverticulum in the current era: A comprehensive review [J]. Gen Thorac Cardiovasc Surg, 2015, 63(5): 245–259.   
[22] ASHA SE, MIERS JW. A systematic review and meta-analysis of D-dimer as a rule-out test for suspected acute aortic dissection[J]. Ann Emerg Med, 2015, 66(4): 368–378.   
[23] 李鑫, 李全明, 王伦常, 等. 主动脉夹层生物标志物的应用、探索与展望[J]. 中华普通外科杂志, 2021, 36(4): 318-320.  
[24] NIENABER CA, CLOUGH RE, SAKALIHASAN N, et al. Aortic dissection[J]. Nat Rev Dis Primers, 2016, 2: 16053.   
[25] ERBEL R, ENGBERDING R, DANIEL W, et al. Echocardiography in diagnosis of aortic dissection [J]. Lancet, 1989, 1(8636): 457–461.   
[26] Expert Panels on Vascular Imaging and Interventional Radiology. ACR Appropriateness Criteria $^{®}$ thoracic aorta interventional planning and follow-up [J]. J Am Coll Radiol, 2017, 14(11s): S570–S583.   
[27] 中国医师协会心血管外科分会大血管外科专业委员会. 主动脉夹层诊断与治疗规范中国专家共识[J]. 中华胸心血管外科杂志, 2017, 33(11): 641-654.  
[28] QIN YL, WANG F, LI TX, et al. Endovascular repair compared with medical management of patients with uncomplicated type B acute aortic dissection [J]. J Am Coll Cardiol, 2016, 67(24): 2835–2842.   
[29] XIONG J, CHEN C, WU Z, et al. Recent evolution in use and effectiveness in mainland China of thoracic endovascular aortic repair of type B aortic dissection [J]. Sci Rep, 2017, 7(1): 17350.   
[30] LI DL, ZHANG HK, CHEN XD, et al. Thoracic endovascular aortic repair for type B aortic dissection: Analysis among acute, subacute, and chronic patients [J]. J Am Coll Cardiol, 2016, 67(10): 1255–1257.   
[31] JING Z, LU Q, FENG J, et al. Endovascular repair of aortic dissection involving the left subclavian artery by castor stent graft: A multicentre prospective trial [J]. Eur J Vasc Endovasc

Surg, 2020, 60(6): 854–861.   
[32] LI X, LI W, DAI X, et al. Thoracic endovascular repair for aortic arch pathologies with surgeon modified fenestrated stent grafts: A multicentre retrospective study [J]. Eur J Vasc Endovasc Surg, 2021, 62(5): 758–766.   
[33] WANG L, ZHOU X, GUO D, et al. A new adjustable puncture device for in situ fenestration during thoracic endovascular aortic repair[J]. J Endovasc Ther, 2018, 25(4): 474–479.   
[34] BAI J, WANG C, LIU Y, et al. A novel fenestrating device: Quick fenestrater for reconstructing supra-aortic arteries in situ during thoracic endovascular aortic repair [J]. Can J Cardiol, 2021, 37(10): 1539–1546.   
[35] SHANG T, TIAN L, LI DL, et al. Favourable outcomes of endovascular total aortic arch repair via needle based in situ fenestration at a mean follow-up of 5.4 months [J]. Eur J Vasc Endovasc Surg, 2018, 55(3): 369–376.   
[36] QIN J, ZHAO Z, WANG R, et al. In situ laser fenestration is a feasible method for revascularization of aortic arch during thoracic endovascular aortic repair[J]. J Am Heart Assoc, 2017, 6(4): e004542.   
[37] ZHAO Z, QIN J, YIN M, et al. In situ laser stent graft fenestration of the left subclavian artery during thoracic endovascular repair of type B aortic dissection with limited proximal landing zones: 5-year outcomes [J]. J Vasc Interv Radiol, 2020, 31(8): 1321–1327.   
[38] LI Y, HU Z, WANG J, et al. Endovascular chimney technique for aortic arch pathologies treatment: A systematic review and meta-analysis[J]. Ann Vasc Surg, 2018, 47: 305–315.   
[39] BOUFI M, PATTERSON BO, LOUNDOU AD, et al. Endovascular versus open repair for chronic type B dissection treatment: A meta-analysis [J]. Ann Thorac Surg, 2019, 107(5): 1559–1570.   
[40] SUNDT TM. Intramural hematoma and penetrating atherosclerotic ulcer of the aorta[J]. Ann Thorac Surg, 2007, 83(2): S835–S841.   
[41] CHO KR, STANSON AW, POTTER DD, et al. Penetrating atherosclerotic ulcer of the descending thoracic aorta and arch [J]. J Thorac Cardiovasc Surg, 2004, 127(5): 1393–1399.   
[42] 董智慧, 符伟国, 王玉琦, 等. Stanford B 型主动脉夹层腔内修复术后发生夹层及手术相关性死亡 12 例分析 [J]. 上海医学, 2009, 32(12): 1070-1073.  
[43] DONG ZH, FU WG, WANG YQ, et al. Retrograde type A aortic dissection after endovascular stent graft placement for treatment of type B dissection [J]. Circulation, 2009, 119(5): 735–741.   
[44] DONG Z, FU W, WANG Y, et al. Stent graft-induced new entry after endovascular repair for Stanford type B aortic dissection[J]. J Vasc Surg, 2010, 52(6): 1450–1457.   
[45] WANG L, ZHAO Y, ZHANG W, et al. Retrograde type A aortic dissection after thoracic endovascular aortic repair: Incidence, time trends and risk factors [J]. Semin Thorac Cardiovasc Surg, 2021, 33(3): 639–653.   
[46] CHEN Y, ZHANG S, LIU L, et al. Retrograde type A aortic

dissection after thoracic endovascular aortic repair: A systematic review and meta-analysis [J]. J Am Heart Assoc, 2017, 6(9): e004649.   
[47] CANAUD L, GANDET T, SFEIR J, et al. Risk factors for distal stent graft-induced new entry tear after endovascular repair of thoracic aortic dissection [J]. J Vasc Surg, 2019, 69(5): 1610–1614.   
[48] FATTORI R, MONTGOMERY D, LOVATO L, et al. Survival after endovascular therapy in patients with type B aortic dissection: A report from the International Registry of Acute Aortic Dissection (IRAD) [J]. JACC Cardiovasc Interv, 2013, 6(8): 876–882.   
[49] TONG YH, YU T, ZHOU MJ, et al. Use of 3D printing to

(收稿日期:2022-06-01)  
guide creation of fenestrations in physician-modified stent-grafts for treatment of thoracoabdominal aortic disease [J]. J Endovasc Ther, 2020, 27(3): 385–393.   
[50] 周旻, 史振宇, 王利新, 等. 主动脉夹层Ⅱ期经假腔隔绝促进主动脉重构的早中期结果 [J]. 中华普通外科杂志, 2021, 36(1): 5-9.  
[51] RONG D, GE Y, LIU J, et al. Combined proximal descending aortic endografting plus distal bare metal stenting (PETTICOAT technique) versus conventional proximal descending aortic stent graft repair for complicated type B aortic dissections [J]. Cochrane Database Syst Rev, 2019, 2019(10): CD013149.

(上接第115页)

[14] NIENABER CA, INCE H, WEBER F, et al. Emergency stent graft placement in thoracic aortic dissection and evolving rupture [J]. J Card Surg, 2003, 18(5): 464–470.   
[15] MEI F, HUANG M, WANG K, et al. Physician-modified endograft with left subclavian artery fenestration for ruptured type B aortic dissection[J]. Ann Vasc Surg, 2021, 77: 352.e7-352.e11.   
[16] OZKAN F, AKPINAR E, SERTER T, et al. Ruptured type B aortic dissection presenting with right hemothorax [J]. Diagn Interv Radiol, 2008, 14(1): 6–8.

(收稿日期:2022-05-09)   
[17] TAKAGO S, NISHIDA S, NODA Y, et al. Thoracic endovascular aortic repair of a ruptured acute type B aortic dissection presenting with right hemothorax: A case report and review of the literature [J]. Gen Thorac Cardiovasc Surg, 2021, 69(10): 1438–1443.   
[18] PIFFARETTI G, MENEGOLO M, KAHLBERG A, et al. Hemothorax management after endovascular treatment for thoracic aortic rupture [J]. Eur J Vasc Endovasc Surg, 2015, 50(5): 608–613.

(上接第118页)

[12] LI X, LI W, DAI X, et al. Thoracic endovascular repair for aortic arch pathologies with surgeon modified fenestrated stent grafts: a multicentre retrospective study [J]. Eur J Vasc Endovasc Surg, 2021, 62(5): 758–766.

[13] 刘长建, 刘昭. 3D 打印技术引导预开窗治疗复杂主动脉弓

(收稿日期:2022-03-13)  
部病变[J]. 中国实用外科杂志, 2018, 38(12): 1381-1384.  
[14] 朱杰昌, 戴向晨, 罗宇东, 等. 开窗胸主动脉修复术治疗伴有不良锚定区的急性 Stanford B 型夹层的早期结果分析 [J]. 中华血管外科杂志, 2017, 2(2): 107-111.